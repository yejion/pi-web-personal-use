(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,572247,e=>{"use strict";var t=(0,e.i(171206).__name)(()=>`
  /* Font Awesome icon styling - consolidated */
  .label-icon {
    display: inline-block;
    height: 1em;
    overflow: visible;
    vertical-align: -0.125em;
  }
  
  .node .label-icon path {
    fill: currentColor;
    stroke: revert;
    stroke-width: revert;
  }
`,"getIconStyles");e.s(["getIconStyles",0,t])},569696,e=>{"use strict";var t=e.i(895727),l=e.i(526290);e.s(["channel",0,(e,i)=>t.default.lang.round(l.default.parse(e)[i])],569696)},289066,e=>{"use strict";var t=e.i(142038);e.s(["default",0,function(e){return(0,t.default)(e,4)}])}]);