module.exports=[17810,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_auth_api-key_%5Bprovider%5D_route_actions_053gpxz.js.map