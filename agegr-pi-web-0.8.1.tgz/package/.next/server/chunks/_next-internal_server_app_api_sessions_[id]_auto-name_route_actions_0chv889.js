module.exports=[935871,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_sessions_%5Bid%5D_auto-name_route_actions_0chv889.js.map