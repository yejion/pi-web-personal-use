module.exports=[753659,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_models-config_route_actions_0wtfyz_.js.map