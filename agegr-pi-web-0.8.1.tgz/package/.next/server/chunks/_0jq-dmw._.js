module.exports=[769449,e=>{"use strict";async function s(){let{configureHttpDispatcher:s}=await e.A(834368);s()}e.s(["register",0,s])},834368,e=>{e.v(s=>Promise.all(["server/chunks/[root-of-the-server]__1j8s6-q._.js"].map(s=>e.l(s))).then(()=>s(623542)))}];

//# sourceMappingURL=_0jq-dmw._.js.map