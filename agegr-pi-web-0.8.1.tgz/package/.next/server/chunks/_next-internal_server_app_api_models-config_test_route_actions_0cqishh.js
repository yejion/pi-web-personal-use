module.exports=[919190,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_models-config_test_route_actions_0cqishh.js.map