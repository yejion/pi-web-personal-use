module.exports=[287867,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_skills_update_route_actions_029znbo.js.map