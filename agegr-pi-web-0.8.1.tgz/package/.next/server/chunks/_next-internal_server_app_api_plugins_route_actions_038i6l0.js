module.exports=[6494,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_plugins_route_actions_038i6l0.js.map