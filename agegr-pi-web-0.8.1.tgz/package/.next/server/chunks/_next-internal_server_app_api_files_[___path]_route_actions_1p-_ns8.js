module.exports=[569453,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_files_%5B___path%5D_route_actions_1p-_ns8.js.map