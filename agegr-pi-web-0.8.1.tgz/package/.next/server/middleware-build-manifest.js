globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/jZyaRvQNGon3jRlesncC-/_buildManifest.js",
    "static/jZyaRvQNGon3jRlesncC-/_ssgManifest.js",
    "static/jZyaRvQNGon3jRlesncC-/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/05kafvajig4wu.js",
    "static/chunks/1pinf87blzrqi.js",
    "static/chunks/2g05-lers809t.js",
    "static/chunks/36tmjn7k_adko.js",
    "static/chunks/turbopack-3q-3t76jwmeze.js"
  ]
};
