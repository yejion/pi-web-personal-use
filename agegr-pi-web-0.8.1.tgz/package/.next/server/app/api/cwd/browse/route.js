var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cwd/browse/route.js")
R.c("server/chunks/[root-of-the-server]__1k4d5xi._.js")
R.c("server/chunks/[root-of-the-server]__0--l0zb._.js")
R.c("server/chunks/node_modules_next_08s853w._.js")
R.c("server/chunks/_next-internal_server_app_api_cwd_browse_route_actions_0v-2a7e.js")
R.m(5410)
module.exports=R.m(5410).exports
