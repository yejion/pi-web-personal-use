1:"$Sreact.fragment"
2:I[897367,["/_next/static/chunks/3ofjqw98d6xwr.js"],"ViewportBoundary"]
3:I[897367,["/_next/static/chunks/3ofjqw98d6xwr.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[27201,["/_next/static/chunks/3ofjqw98d6xwr.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","link","0",{"rel":"icon","href":"/favicon.ico?favicon.3c3v8vvz-eack.ico","sizes":"512x512","type":"image/x-icon"}],["$","$L5","1",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"wCAu9_A2a_VRm5-ovSjCz"}
