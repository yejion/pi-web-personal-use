1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[559665,["/_next/static/chunks/3ofjqw98d6xwr.js","/_next/static/chunks/2jp2v90nczasj.js","/_next/static/chunks/0efywo652ol50.js","/_next/static/chunks/3l6bwn061vy22.js"],"AppShell"]
4:I[897367,["/_next/static/chunks/3ofjqw98d6xwr.js"],"OutletBoundary"]
0:{"rsc":["$","$1","c",{"children":[["$","$2",null,{"children":["$","$L3",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/2jp2v90nczasj.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/0efywo652ol50.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/3l6bwn061vy22.js","async":true}]],["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"jZyaRvQNGon3jRlesncC-"}
5:null
